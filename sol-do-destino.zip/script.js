
const mensagens = [
    "", "", "", "", "",  // preenchidas até carta 4 antes
    "O tempo trabalha contigo. Suas raízes crescem onde a paciência floresce. Rahela sussurra: nutra-se com calma, tudo amadurece.",
    "A confusão é só uma névoa temporária. A Sol pede: não decida no escuro. Rahela guarda tua clareza.",
    "Nem tudo que reluz é ouro, nem toda ameaça é real. Rahela diz: sinta o instinto, mas caminhe com sabedoria.",
    "Fim inevitável. A Sol ilumina o luto e a libertação. Rahela acolhe o renascer que vem após o não.",
    "Um presente inesperado chega com perfume de gratidão. Rahela sorri: aceita o carinho do Universo.",
    "Corte necessário. A Sol brilha no que foi retirado. Rahela afia tua coragem.",
    "Discussões revelam o que precisa ser limpado. A Sol alerta: não repita padrões. Rahela cura a raiz da raiva.",
    "As conversas têm poder. Ouça além das palavras. Rahela fala baixo, mas sua sabedoria ecoa.",
    "Renove-se. Veja com olhos de encanto. Rahela te devolve o riso da alma.",
    "Alerta: esperteza sem verdade vira armadilha. A Sol pede: confie no que vibra real. Rahela protege os puros de coração.",
    "Força demais sem direção vira controle. Rahela sussurra: seja firme, não feroz.",
    "Teu guia te escuta. A Sol brilha onde teus sonhos moram. Rahela confirma: estás no caminho certo.",
    "Mudança positiva à vista. Receba com braços abertos. Rahela já prepara o novo ninho.",
    "Lealdade verdadeira é luz. A Sol abençoa amizades honestas. Rahela reconhece teu coração fiel.",
    "Momento de isolamento sagrado. A Sol revela: o silêncio é um mestre. Rahela observa tuas alturas internas.",
    "Conexões se expandem. Celebre o coletivo. Rahela sorri entre os encontros de almas.",
    "Desafios não impedem, apenas moldam tua coragem. A Sol aponta o cume. Rahela caminha contigo.",
    "A escolha é tua. Ambas estradas têm lições. Rahela te entrega o livre-arbítrio sagrado.",
    "Perdas silenciosas estão drenando tua energia. Rahela avisa: limpa teu campo, cuida do que é teu.",
    "O amor vibra forte. A Sol aquece laços sinceros. Rahela embala os apaixonados.",
    "Compromissos sagrados se formam. A Sol abençoa uniões verdadeiras. Rahela consagra os votos.",
    "Mistérios ainda ocultos virão à luz. Estuda-te. Rahela guarda o saber que está por vir.",
    "Uma mensagem está a caminho. A Sol ilumina palavras reveladoras. Rahela guia tua leitura da verdade.",
    "A energia masculina se manifesta. Seja em ti ou no outro, observe o agir. Rahela equilibra as forças.",
    "A energia feminina te cerca. Escuta a intuição. Rahela desperta o que dorme em teu ventre sutil.",
    "Paz, maturidade e harmonia. A Sol convida ao descanso da alma. Rahela canta sobre o amor calmo.",
    "Tua luz é tua força. Brilha sem medo. Rahela dança contigo nesse renascimento.",
    "Tens sonhado? A Sol reflete em teus mistérios. Rahela vibra em cada intuição revelada.",
    "A resposta já está contigo. A Sol mostra a porta. Rahela te entrega a chave.",
    "Abundância fluindo. A Sol banha teu campo de provisão. Rahela celebra tua colheita.",
    "Firmeza e estabilidade. A Sol ancora teus desejos mais profundos. Rahela segura tua base."
];

function sortearCartas() {
    const container = document.getElementById('cartas');
    const mensagensDiv = document.getElementById('mensagens');
    container.innerHTML = '';
    mensagensDiv.innerHTML = '';

    let indices = Array.from({length: 36}, (_, i) => i + 1);
    indices = indices.sort(() => 0.5 - Math.random()).slice(0, 3);

    indices.forEach(index => {
        const img = document.createElement('img');
        img.src = `https://i.imgur.com/carta${index}.png`;  // Substituir pela URL real
        img.alt = `Carta ${index}`;
        img.onclick = () => {
            mensagensDiv.innerHTML += `<p><strong>Carta ${index}:</strong> ${mensagens[index] || "Mensagem em canalização..."}</p>`;
        };
        container.appendChild(img);
    });
}
